package ogr.scorelab.ucsc.mobility_track;

public class Location2 {
    public long timestamp;
    public double latitude, longitude;
    public float direction, speed;
}
