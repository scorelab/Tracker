package ogr.scorelab.ucsc.mobility_track;

public class Constants {

    public static final String SERVER = "192.168.1.3";
    public static final String DATA_POST_URL = "/api/tracker/location/data";
    public static final String GET_DEVICE_ID_URL = "/api/tracker/findmac/";
    public static final int UPDATE_FREQUENCY = 2000;
}

